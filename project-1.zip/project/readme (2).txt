Requirments (All latest versions)
1.Install Python 
2.flask
3.jinja
4.Matplotlib 
5.Numpy
6.pandas
7.plotly

Steps to run the Project:
1. Open command prompt and Install all the requirements stated above.
2. Extract the zipped file and open the unzipped file
3. Open command prompt and copy the path of folder located.
4. Enter python run.py to excute
5. An ip address will be generated and then paste the Ip address in any webbrowser.