from application import app
from flask import render_template,url_for,request
import pandas as pd
import json
from pandas_datareader._utils import RemoteDataError
import plotly
import plotly.express as px

@app.route('/',methods=['GET', 'POST'])
def index():
    df = pd.read_csv("football.csv",encoding ='latin1')
    if request.method == 'POST':
        xaxis=request.form['xaxis'].replace(' ','')
        yaxis=request.form['yaxis'].replace(' ','')
        colo=request.form['colo'].replace(' ','')
        chart=request.form['chart'].replace(' ','')

        if(xaxis=='none'):
            error = "Select X- axis from list"
            return render_template("index.html", title="home",error=error, chart_style="display: none;")

        elif(yaxis=='none'):
            error = "Select y- axis from list"
            return render_template("index.html", title="home",error=error, chart_style="display: none;")

        elif(colo=='none'):
            error = "Select color from list"
            return render_template("index.html",title="home", error=error, chart_style="display: none;")

        elif(chart=='none'):
            error = "Select chart from list"
            return render_template("index.html",title="home", error=error, chart_style="display: none;")

        elif(yaxis=='none' and colo=='none' and xaxis=='none'and chart=='none'):
            error = "select the options from the above lists"
            return render_template("index.html",title="home", error=error, chart_style="display: none;")

        else:
            if(chart=='bc'):
                fig = px.scatter(df, x=xaxis, y=yaxis,size="goals", color=colo ,hover_name="squad", title="bubble chart")
                graphJSON=json.dumps(fig,cls=plotly.utils.PlotlyJSONEncoder)

            elif(chart=='sbc'):
                fig= px.bar(df, x=xaxis, y=yaxis,color=colo,barmode='stack', title="stacked bar chart")
                graphJSON=json.dumps(fig,cls=plotly.utils.PlotlyJSONEncoder)
            elif(chart=='lc'):
                fig = px.line(df, x= xaxis, y=yaxis, color=colo,symbol="league", title="line chart")
                graphJSON=json.dumps(fig,cls=plotly.utils.PlotlyJSONEncoder)

            elif(chart=='sp'):
                fig = px.scatter(df, x=xaxis, y=yaxis, color=colo, title="Scatter Plot")
                graphJSON=json.dumps(fig,cls=plotly.utils.PlotlyJSONEncoder)

            elif(chart=='bp'):
                fig = px.box(df, x=xaxis, y=yaxis, color=colo, title="box plot")
                graphJSON=json.dumps(fig,cls=plotly.utils.PlotlyJSONEncoder)

            elif(chart=='hg'):
                fig = px.histogram(df, x=xaxis, color=colo, title="histogram")
                graphJSON=json.dumps(fig,cls=plotly.utils.PlotlyJSONEncoder)
            return render_template("index.html", title="home", graphJSON=graphJSON)


            








    else:
        return render_template('index.html',title="home",chart_style="display: none;")

    


    